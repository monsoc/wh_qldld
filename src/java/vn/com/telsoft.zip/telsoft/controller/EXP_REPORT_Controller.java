/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package vn.com.telsoft.controller;

import com.faplib.admin.security.User;
import com.faplib.lib.ClientMessage;
import com.faplib.lib.TSFuncTemplate;
import com.faplib.lib.TelsoftException;
import com.faplib.lib.util.DataUtil;
import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import org.primefaces.model.DefaultStreamedContent;
import vn.com.telsoft.model.EXP_REPORT_Model;

/**
 *
 * @author xuanb
 */
@ManagedBean
@ViewScoped
public class EXP_REPORT_Controller extends TSFuncTemplate implements Serializable {

    private List<Vector> lListReportName = new ArrayList<>();
    private String mstrREPORT_NAME = "";
    private int miUSER_ID;
    private int miQUARTER;
    private int miYEAR;

    /**
     * Creates a new instance of EXP_REPORT_Controller
     */
    public EXP_REPORT_Controller() {
        try {
            lListReportName = (List<Vector>) DataUtil.getData(EXP_REPORT_Model.class, "getListReportName");
            miUSER_ID = Integer.parseInt(User.getUserLogged().getUserId());
        } catch (Exception ex) {
            ex.printStackTrace();
        }

    }

    public DefaultStreamedContent exportExcelReport() {
        SimpleDateFormat fmtDate = new SimpleDateFormat("dd/MM/yyyy");
        DefaultStreamedContent dfs = null;
        try {
            if (mstrREPORT_NAME.equals("KTDV_D30")) {
                dfs = (DefaultStreamedContent) DataUtil.performAction(EXP_REPORT_Model.class, "exportKTDV_D30", miUSER_ID, miYEAR, miQUARTER,mstrREPORT_NAME);
                if (dfs == null) {
                    ClientMessage.log("Không có tồn tại dữ liệu thỏa mãn điều kiện");
                }
            } else if (mstrREPORT_NAME.equals("KTDV_D30_TC")) {
                dfs = (DefaultStreamedContent) DataUtil.performAction(EXP_REPORT_Model.class, "exportKTDV_D30_TC", miUSER_ID, miYEAR, miQUARTER,mstrREPORT_NAME);
                if (dfs == null) {
                    ClientMessage.log("Không có tồn tại dữ liệu thỏa mãn điều kiện");
                }
            }else if (mstrREPORT_NAME.equals("GSDV_CAPUY")) {
                dfs = (DefaultStreamedContent) DataUtil.performAction(EXP_REPORT_Model.class, "exportGSDV_CAPUY", miUSER_ID, miYEAR, miQUARTER,mstrREPORT_NAME);
                if (dfs == null) {
                    ClientMessage.log("Không có tồn tại dữ liệu thỏa mãn điều kiện");
                }
            }else if (mstrREPORT_NAME.equals("GSTCD_CAPUY")) {
                dfs = (DefaultStreamedContent) DataUtil.performAction(EXP_REPORT_Model.class, "exportGSTCD_CAPUY", miUSER_ID, miYEAR, miQUARTER,mstrREPORT_NAME);
                if (dfs == null) {
                    ClientMessage.log("Không có tồn tại dữ liệu thỏa mãn điều kiện");
                }
            }else if (mstrREPORT_NAME.equals("THKL_DV_CAPUY")) {
                dfs = (DefaultStreamedContent) DataUtil.performAction(EXP_REPORT_Model.class, "exportTHKL_DV_CAPUY", miUSER_ID, miYEAR, miQUARTER,mstrREPORT_NAME);
                if (dfs == null) {
                    ClientMessage.log("Không có tồn tại dữ liệu thỏa mãn điều kiện");
                }
            }else if (mstrREPORT_NAME.equals("THKL_TCD_CAPUY")) {
                dfs = (DefaultStreamedContent) DataUtil.performAction(EXP_REPORT_Model.class, "exportTHKL_TCD_CAPUY", miUSER_ID, miYEAR, miQUARTER,mstrREPORT_NAME);
                if (dfs == null) {
                    ClientMessage.log("Không có tồn tại dữ liệu thỏa mãn điều kiện");
                }
            }else if (mstrREPORT_NAME.equals("GQKNKL_DV_CAPUY")) {
                dfs = (DefaultStreamedContent) DataUtil.performAction(EXP_REPORT_Model.class, "exportGQKNKL_DV_CAPUY", miUSER_ID, miYEAR, miQUARTER,mstrREPORT_NAME);
                if (dfs == null) {
                    ClientMessage.log("Không có tồn tại dữ liệu thỏa mãn điều kiện");
                }
            }else if (mstrREPORT_NAME.equals("GQKNKL_TCD_CAPUY")) {
                dfs = (DefaultStreamedContent) DataUtil.performAction(EXP_REPORT_Model.class, "exportGQKNKL_TCD_CAPUY", miUSER_ID, miYEAR, miQUARTER,mstrREPORT_NAME);
                if (dfs == null) {
                    ClientMessage.log("Không có tồn tại dữ liệu thỏa mãn điều kiện");
                }
            }else if (mstrREPORT_NAME.equals("KTDHVPDV")) {
                dfs = (DefaultStreamedContent) DataUtil.performAction(EXP_REPORT_Model.class, "exportKTDHVPDV", miUSER_ID, miYEAR, miQUARTER,mstrREPORT_NAME);
                if (dfs == null) {
                    ClientMessage.log("Không có tồn tại dữ liệu thỏa mãn điều kiện");
                }
            }else if (mstrREPORT_NAME.equals("KTDHVPTC")) {
                dfs = (DefaultStreamedContent) DataUtil.performAction(EXP_REPORT_Model.class, "exportKTDHVPTC", miUSER_ID, miYEAR, miQUARTER,mstrREPORT_NAME);
                if (dfs == null) {
                    ClientMessage.log("Không có tồn tại dữ liệu thỏa mãn điều kiện");
                }
            }else if (mstrREPORT_NAME.equals("KT_THNVKT")) {
                dfs = (DefaultStreamedContent) DataUtil.performAction(EXP_REPORT_Model.class, "exportKT_THNVKT", miUSER_ID, miYEAR, miQUARTER,mstrREPORT_NAME);
                if (dfs == null) {
                    ClientMessage.log("Không có tồn tại dữ liệu thỏa mãn điều kiện");
                }
            }else if (mstrREPORT_NAME.equals("KT_THKL")) {
                dfs = (DefaultStreamedContent) DataUtil.performAction(EXP_REPORT_Model.class, "exportKT_THKL", miUSER_ID, miYEAR, miQUARTER,mstrREPORT_NAME);
                if (dfs == null) {
                    ClientMessage.log("Không có tồn tại dữ liệu thỏa mãn điều kiện");
                }
            }
        } catch (TelsoftException ex) {
            Logger.getLogger(EXP_REPORT_Controller.class.getName()).log(Level.SEVERE, null, ex);
        }
        return dfs;
    }

    @Override
    public void handOK() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void handDelete() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public List<Vector> getListReportName() {
        return lListReportName;
    }

    public void setListReportName(List<Vector> lListReportName) {
        this.lListReportName = lListReportName;
    }

    public String getREPORT_NAME() {
        return mstrREPORT_NAME;
    }

    public void setREPORT_NAME(String strREPORT_NAME) {
        this.mstrREPORT_NAME = strREPORT_NAME;
    }

    public int getQUARTER() {
        return miQUARTER;
    }

    public void setQUARTER(int miQARTER) {
        this.miQUARTER = miQARTER;
    }

    public int getYEAR() {
        return miYEAR;
    }

    public void setYEAR(int miYEAR) {
        this.miYEAR = miYEAR;
    }



}
