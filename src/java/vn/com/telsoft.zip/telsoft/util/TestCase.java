/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package vn.com.telsoft.util;

import java.util.HashMap;
import java.util.Map;

/**
 *
 * @author xuanb
 */
public class TestCase {
    public static void main(String[] arsg){
        String strRuleInfo = "[D|5];[E|5];[L|5];[M|5];[N|1,2,5];[O|4,5];[P|3,5];[Q|5];[R|5];[S|5];[T|5];[U|5];[V|5]";
        Map mRule = new HashMap();
        String strDetailLevel = "1";
        String[] arrCell = strRuleInfo.split(";");
        for(int i=0;i<arrCell.length;i++){
            String strTmpCell = arrCell[i].replaceAll("\\[", "").replaceAll("\\]", "");
            String[] arrRuleMap = strTmpCell.split("\\|");
            if(arrRuleMap.length>=2){
                String strKEY = arrRuleMap[0] + "_" + strDetailLevel;
                mRule.put(strKEY, arrRuleMap[1]);
            }
        }
        
        System.out.println(mRule.get("N_1"));
        
    }
}
