/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package vn.com.telsoft.entity;

import java.io.Serializable;

/**
 *
 * @author xuanb
 */
public class ETT_KTDV_D30 implements Serializable{
    private Integer ID;
    private String CREATE_DATE;
    private Integer GROUP_LEVEL_ID;
    private Integer DETAIL_ID;
    private String GROUP_DES;
    private String DETAIL_DES;
    private String D5;
    private String E5;
    private String F5;
    private String G5;
    private String H5;
    private String I5;
    private String J5;
    private String K5;
    private String L5;
    private String M5;
    private String N5;
    private String O5;
    private String P5;
    private String Q5;
    private String R5;
    private String S5;
    private String T5;
    private String U5;
    private String V5;

    public ETT_KTDV_D30() {
    }

    public ETT_KTDV_D30(Integer ID, String CREATE_DATE, Integer GROUP_LEVEL_ID, Integer DETAIL_ID, String GROUP_DES, String DELTAIL_DES, String D5, String E5, String F5, String G5, String H5, String I5, String J5, String K5, String L5, String M5, String N5, String O5, String P5, String Q5, String R5, String S5, String T5, String U5, String V5) {
        this.ID = ID;
        this.CREATE_DATE = CREATE_DATE;
        this.GROUP_LEVEL_ID = GROUP_LEVEL_ID;
        this.DETAIL_ID = DETAIL_ID;
        this.GROUP_DES = GROUP_DES;
        this.DETAIL_DES = DELTAIL_DES;
        this.D5 = D5;
        this.E5 = E5;
        this.F5 = F5;
        this.G5 = G5;
        this.H5 = H5;
        this.I5 = I5;
        this.J5 = J5;
        this.K5 = K5;
        this.L5 = L5;
        this.M5 = M5;
        this.N5 = N5;
        this.O5 = O5;
        this.P5 = P5;
        this.Q5 = Q5;
        this.R5 = R5;
        this.S5 = S5;
        this.T5 = T5;
        this.U5 = U5;
        this.V5 = V5;
    }

    public String getCREATE_DATE() {
        return CREATE_DATE;
    }

    public void setCREATE_DATE(String CREATE_DATE) {
        this.CREATE_DATE = CREATE_DATE;
    }

    public Integer getGROUP_LEVEL_ID() {
        return GROUP_LEVEL_ID;
    }

    public void setGROUP_LEVEL_ID(Integer GROUP_LEVEL_ID) {
        this.GROUP_LEVEL_ID = GROUP_LEVEL_ID;
    }

    public Integer getDETAIL_ID() {
        return DETAIL_ID;
    }

    public void setDETAIL_ID(Integer DETAIL_ID) {
        this.DETAIL_ID = DETAIL_ID;
    }

    public String getGROUP_DES() {
        return GROUP_DES;
    }

    public void setGROUP_DES(String GROUP_DES) {
        this.GROUP_DES = GROUP_DES;
    }

    public String getDELTAIL_DES() {
        return DETAIL_DES;
    }

    public void setDELTAIL_DES(String DELTAIL_DES) {
        this.DETAIL_DES = DELTAIL_DES;
    }

    public String getValue(String strKEY){
        String strVALUE = "";
        
        return strVALUE;
    }


    public String getD5() {
        return D5;
    }

    public void setD5(String D5) {
        this.D5 = D5;
    }

    public String getE5() {
        return E5;
    }

    public void setE5(String E5) {
        this.E5 = E5;
    }

    public String getF5() {
        return F5;
    }

    public void setF5(String F5) {
        this.F5 = F5;
    }

    public String getG5() {
        return G5;
    }

    public void setG5(String G5) {
        this.G5 = G5;
    }

    public String getH5() {
        return H5;
    }

    public void setH5(String H5) {
        this.H5 = H5;
    }

    public String getI5() {
        return I5;
    }

    public void setI5(String I5) {
        this.I5 = I5;
    }

    public String getJ5() {
        return J5;
    }

    public void setJ5(String J5) {
        this.J5 = J5;
    }

    public String getK5() {
        return K5;
    }

    public void setK5(String K5) {
        this.K5 = K5;
    }

    public String getL5() {
        return L5;
    }

    public void setL5(String L5) {
        this.L5 = L5;
    }

    public String getM5() {
        return M5;
    }

    public void setM5(String M5) {
        this.M5 = M5;
    }

    public String getN5() {
        return N5;
    }

    public void setN5(String N5) {
        this.N5 = N5;
    }

    public String getO5() {
        return O5;
    }

    public void setO5(String O5) {
        this.O5 = O5;
    }

    public String getP5() {
        return P5;
    }

    public void setP5(String P5) {
        this.P5 = P5;
    }

    public String getQ5() {
        return Q5;
    }

    public void setQ5(String Q5) {
        this.Q5 = Q5;
    }

    public String getR5() {
        return R5;
    }

    public void setR5(String R5) {
        this.R5 = R5;
    }

    public String getS5() {
        return S5;
    }

    public void setS5(String S5) {
        this.S5 = S5;
    }

    public String getT5() {
        return T5;
    }

    public void setT5(String T5) {
        this.T5 = T5;
    }

    public String getU5() {
        return U5;
    }

    public void setU5(String U5) {
        this.U5 = U5;
    }

    public String getV5() {
        return V5;
    }

    public void setV5(String V5) {
        this.V5 = V5;
    }

    public Integer getID() {
        return ID;
    }

    public void setID(Integer ID) {
        this.ID = ID;
    }
    
    
}
